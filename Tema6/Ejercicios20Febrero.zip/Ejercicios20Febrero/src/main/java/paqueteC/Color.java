/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package paqueteC;

/**
 *
 * @author Nerea
 */
public enum Color {
    
    AZUL, ROJO, AMARILLO, MORADO, VERDE, NARANJA, BLANCO, NEGRO, GRIS, MARRÓN, TURQUESA;
    
}
