/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package figuraNerea;

/**
 *
 * @author nerea
 */
public interface Movible {
    
    void moverIzq(int x);
    void moverDer(int x);
    void moverArr(int y);
    void moverAba(int y);
    
}
